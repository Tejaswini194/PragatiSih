# Pragati

#### Presentation : https://drive.google.com/file/d/1gXMUA_tD1yF0NlSwdO6kKj8UBfx4wmzQ/view?usp=drive_link


## Main Page


![iman2](https://user-images.githubusercontent.com/68243425/225756796-08d1ac4f-4bf7-4fc8-b058-d9ff342c4ddf.jpeg)

## Government Dashboard

![img1](https://user-images.githubusercontent.com/68243425/225758459-cc03864f-6d9a-4746-a208-00778dfff416.PNG)


## School Dashboard

![img2](https://user-images.githubusercontent.com/68243425/225758455-d52403ca-2b8d-4fd8-8c2e-9f3c704af3f0.jpeg)


## Teachers Dashboard

![imag3](https://user-images.githubusercontent.com/68243425/225758449-63b4c239-fb1c-496b-90f3-e3af6813c6c6.PNG)

## Student Result


![img4](https://user-images.githubusercontent.com/68243425/225758462-8abde79d-79d3-4b74-a2fd-8b7646877b71.jpeg)
