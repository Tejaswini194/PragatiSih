from django.apps import AppConfig


class GovtConfig(AppConfig):
    name = 'govt'
